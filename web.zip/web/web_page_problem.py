

#input the file 
inputFile = open('small.txt', 'r')

# The first input is the number of websites

website_count = inputFile.readline()

#Make a 2d array to store all the data
All_detail = []

for i in range(int(website_count)):
	detail=inputFile.readline()
	detail = detail.split('  ')
	detail = [int(x) for x in detail] 
	#print(detail)
	All_detail.append(detail)


#close the file data was fached from
inputFile.close()
#sort the data using the first colume count

All_detail = sorted(All_detail,key=lambda x: (x[0]))

# Right our output here
file1 = open('output.txt', 'w')
for detail in All_detail:
	detail_str = [str(x) for x in detail]
	detail_str = ','.join(detail_str)
	#print(d)
	file1.writelines(detail_str)
	file1.writelines('\n')
	
file1.close()

